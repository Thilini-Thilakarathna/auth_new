package com.thilini.sms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thilini.sms.model.Employee;
import com.thilini.sms.model.Telephone;
import com.thilini.sms.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public Employee save(Employee employee) {
		
		for(Telephone tel: employee.getTelephone()){
			tel.setEmployee(employee);
		}
	
	return	employeeRepository.save(employee);
	
	}

	@Override
	public List<Employee> fetchAllEmployees() {
		return employeeRepository.findAll();
	}

	@Override
	public Employee fetchEmployees(Employee employee) {
	Optional<Employee> optional= employeeRepository.findById(employee.getId());
	if(optional.isPresent()){
		return optional.get();
	}else{
		return null;
	}
	}

	
	

	
	
}
