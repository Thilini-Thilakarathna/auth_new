# Inventory-Invoice-Service
Invoice Service Microservice project for inventory system
