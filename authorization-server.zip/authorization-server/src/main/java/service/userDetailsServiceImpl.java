package service;

import java.util.Optional;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import repository.userDetailsRepository;

public class userDetailsServiceImpl implements UserDetailsService{

	@Autowired
	userDetailsRepository userDetailsReposit;
	
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Optional<User> optionalUser= userDetailsReposit.findByUserName(username);
		
		
	}

}
