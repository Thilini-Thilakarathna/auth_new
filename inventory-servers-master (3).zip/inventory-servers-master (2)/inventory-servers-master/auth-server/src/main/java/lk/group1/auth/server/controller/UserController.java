package lk.group1.auth.server.controller;


import lk.group1.auth.server.model.User;
import lk.group1.auth.server.service.UserDetailServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController

@RequestMapping(value="/user")
public class UserController {

    @Autowired
    private UserDetailServiceImpl userDetailServiceimpl;

    @RequestMapping(value="/create",method= RequestMethod.POST)
    public User save(@RequestBody User user){



        return userDetailServiceimpl.save(user);


    }

    @RequestMapping(value="/getuser/{id}")
    public ResponseEntity<User> updateEmployee(@PathVariable (value = "id") Integer id, @RequestBody User user1){
        User usere= new User();
       usere.setId(id);
        User users= userDetailServiceimpl.fetchUsers(usere);

        if(users==null){
            return ResponseEntity.notFound().build();
        }

        usere= user1;
        return ResponseEntity.ok().body(users);

    }



        @RequestMapping(value = "/deleteuser/{id}")
    public ResponseEntity<User> deleteUsers(@PathVariable(value = "id") Integer id){
        User use= new User();
        use.setId(id);
        User usere= userDetailServiceimpl.fetchUsers(use);

        if(usere==null){
            return ResponseEntity.notFound().build();
        }

        userDetailServiceimpl.detete(usere);

        return ResponseEntity.ok().build();
        }
}
